//CREACION DE FACTURA DE VENTAS DE COMIDAS RAPIDAS
function mostrar()
{

    let productosFactura =
    JSON.parse(
        localStorage.getItem(
            "productos-factura"
        )
    );

    let subtotal = 0;

    let detalleFactura =
    document.getElementById(
        "detalle-factura"
    );

    detalleFactura.innerHTML = "";

    // RECORRER PRODUCTOS
    for(let i = 0;
        i < productosFactura.length;
        i++)
    {

        let producto =
        productosFactura[i];

        let subtotalProducto =
        parseFloat(
            producto.precio
        ) *
        parseFloat(
            producto.cantidad
        );

        subtotal =
        subtotal +
        subtotalProducto;

        detalleFactura.innerHTML += `

        <tr>

            <td>
                ${producto.id}
            </td>

            <td colspan="2">
                ${producto.titulo}
            </td>

            <td>
                ${producto.cantidad}
            </td>

            <td>
                $${producto.precio}
            </td>

            <td>
                $${subtotalProducto}
            </td>

        </tr>

        `;
    }

    // SUBTOTAL
    document.getElementById(
        "subt"
    ).value =
    subtotal.toFixed(0);

    // IVA
    document.getElementById(
        "iva"
    ).value =
    (
        subtotal * 0.19
    ).toFixed(0);

    // DESCUENTO

    if(document.getElementById(
        "radio1"
    ).checked)
    {

        document.getElementById(
            "desc"
        ).value =
        (
            subtotal * 0.10
        ).toFixed(0);

    }

    if(document.getElementById(
        "radio2"
    ).checked)
    {

        document.getElementById(
            "desc"
        ).value =
        (
            subtotal * 0.00
        ).toFixed(0);

    }

    if(document.getElementById(
        "radio3"
    ).checked)
    {

        document.getElementById(
            "desc"
        ).value =
        (
            subtotal * 0.00
        ).toFixed(0);

    }

    // NETO TOTAL

    document.getElementById(
        "neto"
    ).value =
    (

        parseFloat(
            document.getElementById(
                "subt"
            ).value
        )

        +

        parseFloat(
            document.getElementById(
                "iva"
            ).value
        )

        -

        parseFloat(
            document.getElementById(
                "desc"
            ).value
        )

    ).toFixed(0);

}

mostrar();

function generar()
{

    alert(
        "ESTIMADO CLIENTE SU PEDIDO ESTA EN PROCESO ⏲️"
    );

    localStorage.removeItem(
        "productos-en-carrito"
    );

    localStorage.removeItem(
        "productos-factura"
    );
}

