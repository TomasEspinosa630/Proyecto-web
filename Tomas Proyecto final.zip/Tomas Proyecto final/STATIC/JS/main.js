// PRODUCTOS
//CATALOGO DE PRODUCTOS
const productos = [
    // Computadores portatiles
    {
        id: "Camisa-01",
        titulo: "CAMISETA CLASICA MILLONARIOS",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqtt1izXLYW9T-GNjPkoqPhR-oOeQpUNrAYg&s",
        categoria: {
            nombre: "Camisa",
            id: "Camisas"
        },
        precio: 80000
    },
    {
        id: "Camisa-02",
        titulo: "CAMISETA ATLETICO NACIONAL RETRO",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRiKyZ4spqPfwqOGIju_wsuMAumIJCURaDcQQ&s",
        categoria: {
            nombre: "Camisa",
            id: "Camisas"
        },
        precio: 75000
    },
    {
        id: "Camisa-03",
        titulo: "Camiseta retro América de Cali ",
        imagen: "https://diablografico.com/wp-content/uploads/2021/04/kappa-2000-1.jpg",
        categoria: {
            nombre: "Camisa",
            id: "Camisas"
        },
        precio:  75000
    },
    {
        id: "Camisa-04",
        titulo: "Camiseta retro Santa Fe ",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4Yi545RHzhtU8fh2zlPjxf3uEWyqI-G6fjw&s",
        categoria: {
            nombre: "Camisa",
            id: "Camisas"
        },
        precio: 70000
    },
    
    // Balones
    {
        id: "Balon-01",
        titulo: "Balon fpc 2026",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyu-Fm3q0pBm8l6ne3r1Z5HqGR0f_0o_D8qw&s",
        categoria: {
            nombre: "Balon",
            id: "Balones"
        },
        precio: 350000
    },
    {
        id: "Balon-02",
        titulo: "Balon nba 2026",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxqqCY9ax4pE2Of_sKRn4HHvMtqhkVzAPSqg&s",
        categoria: {
            nombre: "Balon",
            id: "Balones"
        },
        precio: 500000
    },
    {
        id: "Balon-03",
        titulo: "Balon Futbol americano 2026",
        imagen: "https://pbs.twimg.com/media/G912s8_X0AEiTbx.jpg",
        categoria: {
            nombre: "Balon",
            id: "Balones"
        },
        precio: 4668900
    },
    {
        id: "Balon-04",
        titulo: "Balon voleibol",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREohW5fzDSDDwBy2THTz2oUpeEUXuOIFYn-Q&s",
        categoria: {
            nombre: "Balon",
            id: "Balones"
        },
        precio: 250000
    },
    // Accesorios deportivos
    {
        id: "Accesorio-01",
        titulo: "colchonetas",
        imagen: "https://sportfitness.co/cdn/shop/files/071186-1_1080x.png?v=1685110378",
        categoria: {
            nombre: "Material deportivo",
            id: "Material deportivo"
        },
        precio: 80000
    },
    {
        id: "Accesorio-02",
        titulo: "Estacas entrenamiento",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWZ_efSmIzzZ4ZxIICTbNLZAptjFbEhAZPQQ&s",
        categoria: {
            nombre: "Material feportivo",
            id: "Material deportivo"
        },
        precio: 90000
    },
    {
        id: "Accesorio-03",
        titulo: "Conos",
        imagen: "https://m.media-amazon.com/images/I/71IbI5-V1DL.jpg",
        categoria: {
            nombre: "Material deportivo",
            id: "Material deportivo"
        },
        precio: 50000
    },
    {
        id: "Accesorio-04",
        titulo: "Platillos",
        imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwxHcqxfss9JUPgc-yOdeMci3EATaRLFVlLA&s",
        categoria: {
            nombre: "Material deportivo",
            id: "Material deportivo"
        },
        precio: 40000
    }
    
];
//código Js
const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".boton-categoria");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");


function cargarProductos(productosElegidos) {


    contenedorProductos.innerHTML = "";


    productosElegidos.forEach(producto => {


        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">$${producto.precio}</p>
                <button class="producto-agregar" id="${producto.id}">Agregar</button>
            </div>
        `;


        contenedorProductos.append(div);
    })


    actualizarBotonesAgregar();
}


cargarProductos(productos);


botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {


        botonesCategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");


        if (e.currentTarget.id != "todos") {
            const productoCategoria = productos.find(producto => producto.categoria.id === e.currentTarget.id);
            tituloPrincipal.innerText = productoCategoria.categoria.nombre;
            const productosBoton = productos.filter(producto => producto.categoria.id === e.currentTarget.id);
            cargarProductos(productosBoton);
        } else {
            tituloPrincipal.innerText = "Todos los productos";
            cargarProductos(productos);
        }


    })
});


function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");


    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}


let productosEnCarrito;


let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");


if (productosEnCarritoLS) {
    productosEnCarrito = JSON.parse(productosEnCarritoLS);
    actualizarNumerito();
} else {
    productosEnCarrito = [];
}


function agregarAlCarrito(e) {
    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);


    if(productosEnCarrito.some(producto => producto.id === idBoton)) {
        const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
        productosEnCarrito[index].cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }


    actualizarNumerito();


    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}


function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevoNumerito;
}